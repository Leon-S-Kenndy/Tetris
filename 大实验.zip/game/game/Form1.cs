﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace game
{
    



    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

        }

        private bool meetnow(int tempx1,int tempx2,int tempx3,int tempx4, int tempy1, int tempy2,int tempy3,int tempy4,int[,] temp)  //旋转后是否碰撞的计算函数
        {
            if (tempy1 >= 0 && tempy2 >= 0 && tempy3 >= 0 && tempy4 >= 0 && tempy1 < 630 && tempy2 < 630 && tempy3 < 630 && tempy4 < 630)
            {
                bool meet = false;//判断旋转后左右是否碰撞
                if (tempx1 / size < 0 || tempx2 / size < 0 || tempx3 / size < 0 || tempx4 / size < 0 ||
                    tempx1 / size > 9 || tempx2 / size > 9 || tempx3 / size > 9 || tempx4 / size > 9) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                {
                    return true;
                }
                else //没碰到左右边框，看会不会碰到方块
                {
                    if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                    {
                        if (temp[tempy1 / size, tempx1 / size] == 0)//大坐标转换为数组对应值
                            meet = false;
                        else
                            meet = true;
                    }
                    if (meet == false)
                    {
                        if (temp[tempy2 / size, tempx2 / size] == 0)
                            meet = false;
                        else
                            meet = true;
                    }
                    if (meet == false)
                    {
                        if (temp[tempy3 / size, tempx3 / size] == 0)
                            meet = false;
                        else
                            meet = true;
                    }
                    if (meet == false)
                    {
                        if (temp[tempy4 / size, tempx4 / size] == 0)
                            meet = false;
                        else
                            meet = true;
                    }
                    //下落碰撞检测完毕
                    if (meet == false)//没有发生碰撞，保持旋转完状态
                    {
                        return false;
                    }
                    else //发生碰撞，变回来
                    {
                        return true;
                    }
                }
            }
            else
                return true;
        }


        int size = 0;
        int x1, x2, x3, x4, y1, y2, y3, y4;
        int x5, x6, x7, x8, y5, y6, y7, y8;
        int [,] youtu= new int[21,10];
        int [,] P2youtu = new int[21, 10];
        int type = 0;
        int P2type = 0;
        int turn = 0;//记录各个形状方块旋转次数
        int P2turn = 0;
        int specialtype = 0;//特殊的俄罗斯方块
        int P2specialtype = 0;
        bool onlyone = false;//单人模式
        private void special_init(ref int tempspecialtype)//特殊方块生成
        {
            Random r = new Random();
            byte[] buffer = Guid.NewGuid().ToByteArray();
            int iSeed = BitConverter.ToInt32(buffer, 0);
            r = new Random(iSeed);
            tempspecialtype = r.Next(0,11);         
        }
        private void block_init(ref int type,ref int turn)
        {
            
            Random r = new Random();
            byte[] buffer = Guid.NewGuid().ToByteArray();
            int iSeed = BitConverter.ToInt32(buffer, 0);
            r = new Random(iSeed);
            int start = 0;
            int end = 7;
            type = r.Next(start, end);
            specialtype = 0;
            turn = 0;
            switch (type)
            {
                case 0:
                    tianblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;
                case 1:
                    long_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;
                case 2:
                    tublock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;
                case 3:
                    RZblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;
                case 4:                    
                    LZblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;
                case 5:
                    LLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;
                case 6:
                    RLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4);
                    break;

            }
        }
        private void P2block_init(ref int P2type, ref int P2turn)
        {

            Random r = new Random();
            byte[] buffer = Guid.NewGuid().ToByteArray();
            int iSeed = BitConverter.ToInt32(buffer, 0);
            r = new Random(iSeed);
            int start = 0;
            int end = 7;
            P2type = r.Next(start, end);
            P2specialtype = 0;
            P2turn = 0;
            switch (P2type)
            {
                case 0:
                    tianblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;
                case 1:
                    long_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;
                case 2:
                    tublock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;
                case 3:
                    RZblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;
                case 4:
                    LZblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;
                case 5:
                    LLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;
                case 6:
                    RLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8);
                    break;

            }
        }

        private void tianblock_init(ref int x1,ref int x2,ref int y1,ref int y2,ref int x3,ref int x4,ref int y3,ref int y4)//田子型block,type0
        {
            x1 = 4*size;
            x2 = x1 + size;
            x3 = x1;
            x4 = x2;
            y1 = 0;
            y2 = y1;
            y3 = y1 + size;
            y4 = y3;
            
            //////////////////
            // x1y1 x2y2   //
            // x3y3 x4y4  //
            ///////////////
        }
        private void long_init(ref int x1, ref int x2, ref int y1, ref int y2,ref int x3,ref int x4,ref int y3,ref int y4)//长条型block,type1
        {
            x1 = 4 * size;
            x2 = x1;
            x3 = x1;
            x4 = x1;
            y1 = 0;
            y2 = y1+size;
            y3 = y2 + size;
            y4 = y3 + size;
            
            //////////////////
            // x1y1         //
            // x2y2        //
            // x3y3       //
            // x4y4       //
            ///////////////
        }
        private void turn0_long_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)//长条型block,type1
        {
            tempx1 = tempx2-size;
            
            tempx3 = tempx2+size;
            tempx4 = tempx3+size;
            tempy1 = tempy2;

            tempy3 = tempy2;
            tempy4 = tempy2;

            tempturn = 1;
            //////////////////////////////
            // x1y1x2y2x3y3x4y4    //
            //                          //
            /////////////////////////////
        }
        private void turn1_long_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4, ref int tempturn)//长条型block,type1
        {
            tempx1 = tempx2;

            tempx3 = tempx2;
            tempx4 = tempx3;
            tempy1 = tempy2;

            tempy1 = tempy2 - size;
            tempy3 = tempy2 + size;
            tempy4 = tempy3 + size;

            tempturn = 0;
            //////////////////
            // x1y1         //
            // x2y2        //
            // x3y3       //
            // x4y4       //
            ///////////////
        }
        private void tublock_init(ref int x1, ref int x2, ref int y1, ref int y2, ref int x3, ref int x4, ref int y3, ref int y4)//田子型block,type0
        {
            x1 = 4 * size;
            x2 = x1;
            x3 = x1-size;
            x4 = x2+size;
            y1 = 0;
            y2 = y1 + size;
            y3 = y1 + size;
            y4 = y3;
            
            /////////////////////////
            //      x1y1          //
            // x3y3 x2y2 x4y4    //
            //////////////////////
        }
        private void turn0_tublock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)//凸型block,type0
        {
            tempx1 = tempx2 + size;
            tempx3 = tempx2;
            tempx4 = tempx2;
            
            tempy3 = tempy2 - size;
            tempy4 = tempy2 + size;
            tempy1 = tempy2;

            tempturn = 1;
            /////////////////////////
            //  x3y3              //
            //  x2y2   x1y1      //
            //  x4y4            //
            //////////////////////
        }
        private void turn1_tublock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4, ref int tempturn)//凸型block,type0
        {
            tempx1 = tempx2;
            tempx3 = tempx2-size;
            tempx4 = tempx2 + size;
            tempy1 = tempy2 + size; 
            tempy3 = tempy2 ;
            tempy4 = tempy2 ;

            tempturn = 2;
            /////////////////////////
            // x3y3 x2y2 x4y4    //
            //      x1y1          //
            //////////////////////
        }
        private void turn2_tublock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4, ref int tempturn)//凸型block,type0
        {
            tempx1 = tempx2 - size;
            tempx3 = tempx2;
            tempx4 = tempx2;
            tempy1 = tempy2;
            tempy3 = tempy2 - size;
            tempy4 = tempy2 + size;

            tempturn = 3;
            /////////////////////////
            //        x3y3         //
            //   x1y1 x2y2        //
            //        x4y4       //
            //////////////////////
        }
        private void turn3_tublock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4, ref int tempturn)//凸型block,type0
        {
            tempx1 = tempx2;
            tempx3 = tempx2 - size; 
            tempx4 = tempx2 + size;
            tempy1 = tempy2 - size; 
            tempy3 = tempy2 ;
            tempy4 = tempy2 ;

            tempturn = 0;
            /////////////////////////
            //      x1y1          //
            // x3y3 x2y2 x4y4    //
            //////////////////////
        }
        private void RZblock_init(ref int x1, ref int x2, ref int y1, ref int y2, ref int x3, ref int x4, ref int y3, ref int y4)//田子型block,type0
        {
            x2 = 4 * size;
            x1 = x2-size;           
            x3 = x2;
            x4 = x2+size;
            y1 = 0;
            y2 = 0;
            y3 = y1 + size;
            y4 = y3;
            
            //////////////////////////////
            //      x1y1 x2y2          //
            //           x3y3  x4y4    //
            /////////////////////////////
        }
        private void turn0_RZblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx2;
            tempx3 = tempx2 - size;
            tempx4 = tempx3;
            tempy1 = tempy2 - size;
            tempy3 = tempy2;
            tempy4 = tempy3 + size;
            tempturn = 1;
            //////////////////////////////
            //          x1y1           //
            //   x3y3   x2y2           //
            //   x4y4                  //
            /////////////////////////////
        }
        private void turn1_RZblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx2 - size; 
            tempx3 = tempx2;
            tempx4 = tempx3 + size;
            tempy1 = tempy2;
            tempy3 = tempy2 + size;
            tempy4 = tempy3 ;
            tempturn = 0;
            //////////////////////////////
            //      x1y1 x2y2          //
            //           x3y3  x4y4    //
            /////////////////////////////
        }
        private void LZblock_init(ref int x1, ref int x2, ref int y1, ref int y2, ref int x3, ref int x4, ref int y3, ref int y4)//田子型block,type0
        {
            x1 = 4 * size;
            x2 = x1 + size;
            x3 = x1-size;
            x4 = x1;
            y1 = 0;
            y2 = y1;
            y3 = y1 + size;
            y4 = y3;
           
            ////////////////////////////////
            //         x1y1 x2y2          //
            //   x3y3  x4y4              //
            /////////////////////////////
        }
        private void turn0_LZblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx4-size;
            tempx3 = tempx4; 
            tempx2 = tempx1;
            tempy1 = tempy4;
            tempy2 = tempy4 - size; 
            tempy3 = tempy4 + size;
            tempturn = 1;
            //////////////////////////////
            //       x2y2              //
            //       x1y1 x4y4        //
            //            x3y3       //
            //////////////////////////
        }
        private void turn1_LZblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx4;
            tempx3 = tempx1 - size;
            tempx2 = tempx4 + size;
            tempy1 = tempy4 - size;
            tempy3 = tempy4 ;
            tempy2 = tempy1;
            tempturn = 0;
            ////////////////////////////////
            //         x1y1 x2y2          //
            //   x3y3  x4y4              //
            /////////////////////////////
        }

        private void LLblock_init(ref int x1, ref int x2, ref int y1, ref int y2, ref int x3, ref int x4, ref int y3, ref int y4)//田子型block,type0
        {
            x3 = 4 * size;
            x1 = x3+size;
            x2 = x3-size;
            
            x4 = x1;
            y1 = 0;
            y2 = y1 + size;
            y3 = y1 + size;
            y4 = y3;
           
            ////////////////////////////////
            //                x1y1       //
            //     x2y2 x3y3  x4y4      //
            /////////////////////////////
        }
        private void turn0_LLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx4;
            tempx2 = tempx4;
            tempx3 = tempx4 + size;
            tempy1 = tempy4 - 2 * size;
            tempy2 = tempy4 - size;
            tempy3 = tempy4;
            tempturn = 1;
            /////////////////////////////////
            //          x1y1              //
            //          x2y2             //
            //          x4y4  x3y3      //
            /////////////////////////////
        }
        private void turn1_LLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx4 + 2 * size;
            tempx2 = tempx4 + size; 
            tempx3 = tempx4 ;
            tempy1 = tempy4 ;
            tempy2 = tempy4 ;
            tempy3 = tempy4 + size;
            tempturn = 2;
            /////////////////////////////////
            //                            //
            //         x4y4 x2y2 x1y1    //
            //         x3y3             //
            /////////////////////////////
        }
        private void turn2_LLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx4;
            tempx2 = tempx4;
            tempx3 = tempx4 - size;
            tempy1 = tempy4 + 2 * size; 
            tempy2 = tempy4 + size;
            tempy3 = tempy4;
            tempturn = 3;
            /////////////////////////////////
            //      x3y3    x4y4          //
            //              x2y2         //
            //              x1y1        //
            /////////////////////////////
        }
        private void turn3_LLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx4;
            tempx2 = tempx4 - 2 * size; 
            tempx3 = tempx4 - size;
            tempy1 = tempy4 - size;
            tempy2 = tempy4;
            tempy3 = tempy4;
            tempturn = 0;
            ////////////////////////////////
            //                x1y1       //
            //     x2y2 x3y3  x4y4      //
            /////////////////////////////
        }
        private void RLblock_init(ref int x1, ref int x2, ref int y1, ref int y2, ref int x3, ref int x4, ref int y3, ref int y4)//田子型block,type0
        {
            x3 = 4 * size;
            x1 = x3-size;
            x2 = x3 - size;
            x4 = x3 + size; 
            y1 = 0;
            y2 = y1+size;
            y3 = y1 + size;
            y4 = y3;
            
            ////////////////////////////////
            //         x1y1              //
            //         x2y2 x3y3  x4y4  //
            /////////////////////////////
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void turn0_RLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx2 + size;
            tempx3 = tempx2;
            tempx4 = tempx2;
            tempy1 = tempy2;
            tempy3 = tempy2 + size;
            tempy4 = tempy3 + size;
            tempturn = 1;
            ////////////////////////////////
            //      x2y2 x1y1            //
            //      x3y3                //
            //      x4y4               //
            /////////////////////////////
        }
        private void turn1_RLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx2;
            tempx3 = tempx2 - size;
            tempx4 = tempx3 - size;
            tempy1 = tempy2 + size;
            tempy3 = tempy2;
            tempy4 = tempy2;
           
            tempturn = 2;
            ////////////////////////////////
            //                           //
            //    x4y4  x3y3 x2y2       //
            //               x1y1      //
            ////////////////////////////
        }
        private void turn2_RLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx2 - size;
            tempx3 = tempx2;
            tempx4 = tempx3;
            tempy1 = tempy2;
            tempy3 = tempy2 - size;
            tempy4 = tempy3 - size;            
            tempturn = 3;
            ////////////////////////////////
            //               x4y4        //
            //               x3y3       //
            //          x1y1 x2y2      //
            ////////////////////////////
        }
        private void turn3_RLblock_init(ref int tempx1, ref int tempx2, ref int tempy1, ref int tempy2, ref int tempx3, ref int tempx4, ref int tempy3, ref int tempy4,ref int tempturn)
        {
            tempx1 = tempx2;
            tempx3 = tempx2 + size;
            tempx4 = tempx3 + size;
            tempy1 = tempy2 - size;
            tempy3 = tempy2;
            tempy4 = tempy3;
            tempturn = 0;
            ////////////////////////////////
            //         x1y1              //
            //         x2y2 x3y3  x4y4  //
            /////////////////////////////
        }


        private void button1_Click(object sender, EventArgs e)//单人游戏开始
        {
            timer1.Interval = 1000;
            onlyone = true;
            speed = 0;
            level = 1;
            Bitmap canvas = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap image = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Graphics g = Graphics.FromImage(image);
            Pen pen = new Pen(Color.Red, 2);
            Pen greypen = new Pen(Color.Gray, 2);
            SolidBrush brush = new SolidBrush(Color.Coral);
            pictureBox1.BackgroundImage = canvas;
            size=pictureBox1.ClientSize.Width / 10;
            
            block_init(ref type,ref turn);
            special_init(ref specialtype);
            if (specialtype == 1)
            {
                pen.Color = Color.Red;
                brush.Color = Color.Coral;
            }
            else if (specialtype == 2)
            {
                pen.Color = Color.MediumSeaGreen;
                brush.Color = Color.LimeGreen;
            }
            else
            {
                pen.Color = Color.RoyalBlue;
                brush.Color = Color.SlateBlue;
            }
            g.DrawRectangle(pen, x1, y1, size, size);
            g.DrawRectangle(pen, x2, y2, size, size);
            g.DrawRectangle(pen, x3, y3, size, size);
            g.DrawRectangle(pen, x4, y4, size, size);
            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 4, size - 4);
            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 4, size - 4);
            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 4, size - 4);
            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 4, size - 4);
            pictureBox1.Image = image;
            pictureBox1.Refresh();
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    youtu[i, j] = 0;
                }
            }
                    timer1.Start();
            label1.Text = "速度:" + level;

        }
        int speed=0;
        int level=0;

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Interval = 1000;
            onlyone = false;
            speed = 0;
            level = 1;
            Bitmap P1canvas = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap P1image = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Graphics P1g = Graphics.FromImage(P1image);
            Pen P1pen = new Pen(Color.Red, 2);
            Pen P1greypen = new Pen(Color.Gray, 2);
            SolidBrush P1brush = new SolidBrush(Color.Coral);
            pictureBox1.BackgroundImage = P1canvas;
            specialtype = 0;
            P2specialtype = 0;
            Bitmap P2canvas = new Bitmap(pictureBox2.ClientSize.Width, pictureBox2.ClientSize.Height);
            Bitmap P2image = new Bitmap(pictureBox2.ClientSize.Width, pictureBox2.ClientSize.Height);
            Graphics P2g = Graphics.FromImage(P2image);
            Pen P2pen = new Pen(Color.Red, 2);
            Pen P2greypen = new Pen(Color.Gray, 2);
            SolidBrush P2brush = new SolidBrush(Color.Coral);
            pictureBox2.BackgroundImage = P2canvas;


            size = pictureBox1.ClientSize.Width / 10;
            //玩家一画面生成
            block_init(ref type, ref turn);
            if (specialtype == 1)
            {
                P1pen.Color = Color.Red;
                P1brush.Color = Color.Coral;
            }
            else if (specialtype == 2)
            {
                P1pen.Color = Color.MediumSeaGreen;
                P1brush.Color = Color.LimeGreen;
            }
            else
            {
                P1pen.Color = Color.RoyalBlue;
                P1brush.Color = Color.SlateBlue;
            }
            P1g.DrawRectangle(P1pen, x1, y1, size, size);
            P1g.DrawRectangle(P1pen, x2, y2, size, size);
            P1g.DrawRectangle(P1pen, x3, y3, size, size);
            P1g.DrawRectangle(P1pen, x4, y4, size, size);
            P1g.FillRectangle(P1brush, x1 + 2, y1 + 2, size - 4, size - 4);
            P1g.FillRectangle(P1brush, x2 + 2, y2 + 2, size - 4, size - 4);
            P1g.FillRectangle(P1brush, x3 + 2, y3 + 2, size - 4, size - 4);
            P1g.FillRectangle(P1brush, x4 + 2, y4 + 2, size - 4, size - 4);
            pictureBox1.Image = P1image;
            
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    youtu[i, j] = 0;
                }
            }

            //玩家二画面生成
            P2block_init(ref P2type, ref P2turn);
            if (P2specialtype == 1)
            {
                P2pen.Color = Color.Red;
                P2brush.Color = Color.Coral;
            }
            else if (P2specialtype == 2)
            {
                P2pen.Color = Color.MediumSeaGreen;
                P2brush.Color = Color.LimeGreen;
            }
            else
            {
                P2pen.Color = Color.RoyalBlue;
                P2brush.Color = Color.SlateBlue;
            }
            P2g.DrawRectangle(P2pen, x5, y5, size, size);
            P2g.DrawRectangle(P2pen, x6, y6, size, size);
            P2g.DrawRectangle(P2pen, x7, y7, size, size);
            P2g.DrawRectangle(P2pen, x8, y8, size, size);
            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 4, size - 4);
            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 4, size - 4);
            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 4, size - 4);
            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 4, size - 4);
            pictureBox2.Image = P2image;
            pictureBox2.Refresh();
            pictureBox1.Refresh();
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    P2youtu[i, j] = 0;
                }
            }
            timer2.Start();
            label1.Text = "速度:" + level;

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            speed++;
            if (speed > 60 * level && level < 3)
            {
                level++;
                speed = 0;
                timer2.Interval = timer2.Interval / 2;
                label1.Text = "速度:" + level;
            }
            // 初始化前景图片画布
            Bitmap P1image = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap P2image = new Bitmap(pictureBox2.ClientSize.Width, pictureBox2.ClientSize.Height);
            // 初始化整个画布
            Bitmap P1newcanvas = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap P1canvas = (Bitmap)pictureBox1.BackgroundImage;
            Bitmap P2newcanvas = new Bitmap(pictureBox2.ClientSize.Width, pictureBox2.ClientSize.Height);
            Bitmap P2canvas = (Bitmap)pictureBox2.BackgroundImage;
            // 初始化图形面板
            Graphics P1g = Graphics.FromImage(P1image);
            Graphics P1bg = Graphics.FromImage(P1canvas);
            Graphics P1nbg = Graphics.FromImage(P1newcanvas);//如有一行消除 则在这个上面重新绘制方块
            Graphics P2g = Graphics.FromImage(P2image);
            Graphics P2bg = Graphics.FromImage(P2canvas);
            Graphics P2nbg = Graphics.FromImage(P2newcanvas);//如有一行消除 则在这个上面重新绘制方块
            // 判断笔刷
            Pen P1pen = new Pen(Color.Red, 2);
            Pen P1greypen = new Pen(Color.Gray, 2);
            SolidBrush P1brush = new SolidBrush(Color.Coral);
            Pen P2pen = new Pen(Color.Red, 2);
            Pen P2greypen = new Pen(Color.Gray, 2);
            SolidBrush P2brush = new SolidBrush(Color.Coral);
            if (specialtype == 1)
            {
                P1pen.Color = Color.Red;
                P1brush.Color = Color.Coral;
            }
            else if (specialtype == 2)
            {
                P1pen.Color = Color.MediumSeaGreen;
                P1brush.Color = Color.LimeGreen;
            }
            else
            {
                P1pen.Color = Color.RoyalBlue;
                P1brush.Color = Color.SlateBlue;
            }
            if (P2specialtype == 1)
            {
                P2pen.Color = Color.Red;
                P2brush.Color = Color.Coral;
            }
            else if (P2specialtype == 2)
            {
                P2pen.Color = Color.MediumSeaGreen;
                P2brush.Color = Color.LimeGreen;
            }
            else
            {
                P2pen.Color = Color.RoyalBlue;
                P2brush.Color = Color.SlateBlue;
            }
            //笔刷生成完毕
            //判断添加下落预判图  
            bool predict = false;
            int predictcount = 0;
            int predictx1 = x1, predictx2 = x2, predictx3 = x3, predictx4 = x4, predicty1 = y1, predicty2 = y2, predicty3 = y3, predicty4 = y4;
            while (!predict)
            {
                predictcount++;
                if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                {
                    if (predictcount != 1)
                    {
                        P1g.DrawRectangle(P1greypen, predictx1, predicty1, size, size);
                        P1g.DrawRectangle(P1greypen, predictx2, predicty2, size, size);
                        P1g.DrawRectangle(P1greypen, predictx3, predicty3, size, size);
                        P1g.DrawRectangle(P1greypen, predictx4, predicty4, size, size);
                    }
                    predict = true;
                }
                else //进行碰撞计算再绘图
                {
                    if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                    {
                        if (youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (youtu[predicty2 / size + 1, predictx2 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (youtu[predicty3 / size + 1, predictx3 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (youtu[predicty4 / size + 1, predictx4 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    //下落碰撞检测完毕
                    if (predict == false)//没有发生碰撞，下落
                    {
                        predicty1 = predicty1 + size;
                        predicty2 = predicty2 + size;
                        predicty3 = predicty3 + size;
                        predicty4 = predicty4 + size;
                    }
                    else
                    {
                        if (predictcount != 1)
                        {
                            P1g.DrawRectangle(P1greypen, predictx1, predicty1, size, size);
                            P1g.DrawRectangle(P1greypen, predictx2, predicty2, size, size);
                            P1g.DrawRectangle(P1greypen, predictx3, predicty3, size, size);
                            P1g.DrawRectangle(P1greypen, predictx4, predicty4, size, size);
                        }
                        predict = true;
                    }
                }
            }
            predict = false;
            predictcount = 0;
            predictx1 = x5; predictx2 = x6; predictx3 = x7; predictx4 = x8; predicty1 = y5; predicty2 = y6; predicty3 = y7; predicty4 = y8;
            while (!predict)
            {
                predictcount++;
                if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                {
                    if (predictcount != 1)
                    {
                        P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                        P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                        P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                        P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                    }
                    predict = true;
                }
                else //进行碰撞计算再绘图
                {
                    if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                    {
                        if (P2youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (P2youtu[predicty2 / size + 1, predictx2 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (P2youtu[predicty3 / size + 1, predictx3 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (P2youtu[predicty4 / size + 1, predictx4 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    //下落碰撞检测完毕
                    if (predict == false)//没有发生碰撞，下落
                    {
                        predicty1 = predicty1 + size;
                        predicty2 = predicty2 + size;
                        predicty3 = predicty3 + size;
                        predicty4 = predicty4 + size;
                    }
                    else
                    {
                        if (predictcount != 1)
                        {
                            P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                            P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                            P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                            P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                        }
                        predict = true;
                    }
                }
            }
            ///////////////////////////下落图添加完毕////////////////////


            //////////////////////判断下落是否碰撞/////////////////////
            bool meet = false;
            if (y1 / size > 19 || y2 / size > 19 || y3 / size > 19 || y4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
            {
                if (specialtype == 1)
                {
                    youtu[y1 / size, x1 / size] = 2;
                    youtu[y2 / size, x2 / size] = 2;
                    youtu[y3 / size, x3 / size] = 2;
                    youtu[y4 / size, x4 / size] = 2;
                }
                else if (specialtype == 2)
                {
                    youtu[y1 / size, x1 / size] = 3;
                    youtu[y2 / size, x2 / size] = 3;
                    youtu[y3 / size, x3 / size] = 3;
                    youtu[y4 / size, x4 / size] = 3;
                }
                else
                {
                    youtu[y1 / size, x1 / size] = 1;
                    youtu[y2 / size, x2 / size] = 1;
                    youtu[y3 / size, x3 / size] = 1;
                    youtu[y4 / size, x4 / size] = 1;
                }

                P1bg.DrawRectangle(P1pen, x1, y1, size, size);
                P1bg.DrawRectangle(P1pen, x2, y2, size, size);
                P1bg.DrawRectangle(P1pen, x3, y3, size, size);
                P1bg.DrawRectangle(P1pen, x4, y4, size, size);
                P1bg.FillRectangle(P1brush, x1 + 2, y1 + 2, size - 3, size - 3);
                P1bg.FillRectangle(P1brush, x2 + 2, y2 + 2, size - 3, size - 3);
                P1bg.FillRectangle(P1brush, x3 + 2, y3 + 2, size - 3, size - 3);
                P1bg.FillRectangle(P1brush, x4 + 2, y4 + 2, size - 3, size - 3);
                
                block_init(ref type, ref turn);
                if (specialtype == 1)
                {
                    P1pen.Color = Color.Red;
                    P1brush.Color = Color.Coral;
                }
                else if (specialtype == 2)
                {
                    P1pen.Color = Color.MediumSeaGreen;
                    P1brush.Color = Color.LimeGreen;
                }
                else
                {
                    P1pen.Color = Color.RoyalBlue;
                    P1brush.Color = Color.SlateBlue;
                }
                P1g.DrawRectangle(P1pen, x1, y1, size, size);
                P1g.DrawRectangle(P1pen, x2, y2, size, size);
                P1g.DrawRectangle(P1pen, x3, y3, size, size);
                P1g.DrawRectangle(P1pen, x4, y4, size, size);
                P1g.FillRectangle(P1brush, x1 + 2, y1 + 2, size - 3, size - 3);
                P1g.FillRectangle(P1brush, x2 + 2, y2 + 2, size - 3, size - 3);
                P1g.FillRectangle(P1brush, x3 + 2, y3 + 2, size - 3, size - 3);
                P1g.FillRectangle(P1brush, x4 + 2, y4 + 2, size - 3, size - 3);
            }
            else //进行碰撞计算再绘图
            {
                if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                {
                    if (youtu[y1 / size + 1, x1 / size] == 0)//大坐标转换为数组对应值
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (youtu[y2 / size + 1, x2 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (youtu[y3 / size + 1, x3 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (youtu[y4 / size + 1, x4 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                //下落碰撞检测完毕,开始绘图
                if (meet == false)//没有发生碰撞，下落
                {
                    y1 = y1 + size;
                    y2 = y2 + size;
                    y3 = y3 + size;
                    y4 = y4 + size;
                    P1g.DrawRectangle(P1pen, x1, y1, size, size);
                    P1g.DrawRectangle(P1pen, x2, y2, size, size);
                    P1g.DrawRectangle(P1pen, x3, y3, size, size);
                    P1g.DrawRectangle(P1pen, x4, y4, size, size);
                    P1g.FillRectangle(P1brush, x1 + 2, y1 + 2, size - 3, size - 3);
                    P1g.FillRectangle(P1brush, x2 + 2, y2 + 2, size - 3, size - 3);
                    P1g.FillRectangle(P1brush, x3 + 2, y3 + 2, size - 3, size - 3);
                    P1g.FillRectangle(P1brush, x4 + 2, y4 + 2, size - 3, size - 3);
                }
                else
                {
                    if (specialtype == 1)
                    {
                        youtu[y1 / size, x1 / size] = 2;
                        youtu[y2 / size, x2 / size] = 2;
                        youtu[y3 / size, x3 / size] = 2;
                        youtu[y4 / size, x4 / size] = 2;
                    }
                    else if (specialtype == 2)
                    {
                        youtu[y1 / size, x1 / size] = 3;
                        youtu[y2 / size, x2 / size] = 3;
                        youtu[y3 / size, x3 / size] = 3;
                        youtu[y4 / size, x4 / size] = 3;
                    }
                    else
                    {
                        youtu[y1 / size, x1 / size] = 1;
                        youtu[y2 / size, x2 / size] = 1;
                        youtu[y3 / size, x3 / size] = 1;
                        youtu[y4 / size, x4 / size] = 1;
                    }


                    P1bg.DrawRectangle(P1pen, x1, y1, size, size);
                    P1bg.DrawRectangle(P1pen, x2, y2, size, size);
                    P1bg.DrawRectangle(P1pen, x3, y3, size, size);
                    P1bg.DrawRectangle(P1pen, x4, y4, size, size);
                    P1bg.FillRectangle(P1brush, x1 + 2, y1 + 2, size - 3, size - 3);
                    P1bg.FillRectangle(P1brush, x2 + 2, y2 + 2, size - 3, size - 3);
                    P1bg.FillRectangle(P1brush, x3 + 2, y3 + 2, size - 3, size - 3);
                    P1bg.FillRectangle(P1brush, x4 + 2, y4 + 2, size - 3, size - 3);
                    
                    block_init(ref type, ref turn);
                    if (specialtype == 1)
                    {
                        P1pen.Color = Color.Red;
                        P1brush.Color = Color.Coral;
                    }
                    else if (specialtype == 2)
                    {
                        P1pen.Color = Color.MediumSeaGreen;
                        P1brush.Color = Color.LimeGreen;
                    }
                    else
                    {
                        P1pen.Color = Color.RoyalBlue;
                        P1brush.Color = Color.SlateBlue;
                    }
                    P1g.DrawRectangle(P1pen, x1, y1, size, size);
                    P1g.DrawRectangle(P1pen, x2, y2, size, size);
                    P1g.DrawRectangle(P1pen, x3, y3, size, size);
                    P1g.DrawRectangle(P1pen, x4, y4, size, size);
                    P1g.FillRectangle(P1brush, x1 + 2, y1 + 2, size - 3, size - 3);
                    P1g.FillRectangle(P1brush, x2 + 2, y2 + 2, size - 3, size - 3);
                    P1g.FillRectangle(P1brush, x3 + 2, y3 + 2, size - 3, size - 3);
                    P1g.FillRectangle(P1brush, x4 + 2, y4 + 2, size - 3, size - 3);
                }
            }
            //////////////P2部分下落绘图检测//////////
            meet = false;
            if (y5 / size > 19 || y6 / size > 19 || y7 / size > 19 || y8 / size > 19) //下落到最低，直接绘图，不用计算碰撞
            {
                if (P2specialtype == 1)
                {
                    P2youtu[y5 / size, x5 / size] = 2;
                    P2youtu[y6 / size, x6 / size] = 2;
                    P2youtu[y7 / size, x7 / size] = 2;
                    P2youtu[y8 / size, x8 / size] = 2;
                }
                else if (P2specialtype == 2)
                {
                    P2youtu[y5 / size, x5 / size] = 3;
                    P2youtu[y6 / size, x6 / size] = 3;
                    P2youtu[y7 / size, x7 / size] = 3;
                    P2youtu[y8 / size, x8 / size] = 3;
                }
                else
                {
                    P2youtu[y5 / size, x5 / size] = 1;
                    P2youtu[y6 / size, x6 / size] = 1;
                    P2youtu[y7 / size, x7 / size] = 1;
                    P2youtu[y8 / size, x8 / size] = 1;
                }

                P2bg.DrawRectangle(P2pen, x5, y5, size, size);
                P2bg.DrawRectangle(P2pen, x6, y6, size, size);
                P2bg.DrawRectangle(P2pen, x7, y7, size, size);
                P2bg.DrawRectangle(P2pen, x8, y8, size, size);
                P2bg.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                P2bg.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                P2bg.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                P2bg.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                
                P2block_init(ref P2type, ref P2turn);
                if (P2specialtype == 1)
                {
                    P2pen.Color = Color.Red;
                    P2brush.Color = Color.Coral;
                }
                else if (P2specialtype == 2)
                {
                    P2pen.Color = Color.MediumSeaGreen;
                    P2brush.Color = Color.LimeGreen;
                }
                else
                {
                    P2pen.Color = Color.RoyalBlue;
                    P2brush.Color = Color.SlateBlue;
                }
                P2g.DrawRectangle(P2pen, x5, y5, size, size);
                P2g.DrawRectangle(P2pen, x6, y6, size, size);
                P2g.DrawRectangle(P2pen, x7, y7, size, size);
                P2g.DrawRectangle(P2pen, x8, y8, size, size);
                P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
            }
            else //进行碰撞计算再绘图
            {
                if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                {
                    if (P2youtu[y5 / size + 1, x5 / size] == 0)//大坐标转换为数组对应值
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (P2youtu[y6 / size + 1, x6 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (P2youtu[y7 / size + 1, x7 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (P2youtu[y8 / size + 1, x8 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                //下落碰撞检测完毕,开始绘图
                if (meet == false)//没有发生碰撞，下落
                {
                    y5 = y5 + size;
                    y6 = y6 + size;
                    y7 = y7 + size;
                    y8 = y8 + size;
                    P2g.DrawRectangle(P2pen, x5, y5, size, size);
                    P2g.DrawRectangle(P2pen, x6, y6, size, size);
                    P2g.DrawRectangle(P2pen, x7, y7, size, size);
                    P2g.DrawRectangle(P2pen, x8, y8, size, size);
                    P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                    P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                    P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                    P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                }
                else
                {
                    if (P2specialtype == 1)
                    {
                        P2youtu[y5 / size, x5 / size] = 2;
                        P2youtu[y6 / size, x6 / size] = 2;
                        P2youtu[y7 / size, x7 / size] = 2;
                        P2youtu[y8 / size, x8 / size] = 2;
                    }
                    else if (P2specialtype == 2)
                    {
                        P2youtu[y5 / size, x5 / size] = 3;
                        P2youtu[y6 / size, x6 / size] = 3;
                        P2youtu[y7 / size, x7 / size] = 3;
                        P2youtu[y8 / size, x8 / size] = 3;
                    }
                    else
                    {
                        P2youtu[y5 / size, x5 / size] = 1;
                        P2youtu[y6 / size, x6 / size] = 1;
                        P2youtu[y7 / size, x7 / size] = 1;
                        P2youtu[y8 / size, x8 / size] = 1;
                    }


                    P2bg.DrawRectangle(P2pen, x5, y5, size, size);
                    P2bg.DrawRectangle(P2pen, x6, y6, size, size);
                    P2bg.DrawRectangle(P2pen, x7, y7, size, size);
                    P2bg.DrawRectangle(P2pen, x8, y8, size, size);
                    P2bg.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                    P2bg.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                    P2bg.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                    P2bg.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                    
                    P2block_init(ref P2type, ref P2turn);
                    if (P2specialtype == 1)
                    {
                        P2pen.Color = Color.Red;
                        P2brush.Color = Color.Coral;
                    }
                    else if (P2specialtype == 2)
                    {
                        P2pen.Color = Color.MediumSeaGreen;
                        P2brush.Color = Color.LimeGreen;
                    }
                    else
                    {
                        P2pen.Color = Color.RoyalBlue;
                        P2brush.Color = Color.SlateBlue;
                    }
                    P2g.DrawRectangle(P2pen, x5, y5, size, size);
                    P2g.DrawRectangle(P2pen, x6, y6, size, size);
                    P2g.DrawRectangle(P2pen, x7, y7, size, size);
                    P2g.DrawRectangle(P2pen, x8, y8, size, size);
                    P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                    P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                    P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                    P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                }
            }

            /////////////////////下落图绘制完毕////////////////////

            /////////////////判断有没有特殊方块////////////////
            int iSeed = 0;
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (youtu[i, j] == 2)//有爆炸方块，随机消除这一排
                    {
                        youtu[i, j] = 1;//先变回普通方块
                        for (int boom = 0; boom < 10; boom++)
                        {
                            if (boom == j)
                                continue;
                            if (youtu[i, boom] == 1)//对于有方块的随机消除
                            {
                                Random r = new Random();
                                byte[] buffer = Guid.NewGuid().ToByteArray();
                                iSeed = BitConverter.ToInt32(buffer, 0);
                                r = new Random(iSeed);
                                youtu[i, boom] = r.Next(0, 2);
                            }
                        }
                    }
                    if (youtu[i, j] == 3)//有生长方块
                    {
                        youtu[i, j] = 1;//先变回普通方块
                        int space = 0;
                        int newblock = 0;
                        for (int grow = 0; grow < 10; grow++)
                        {
                            if (youtu[i, grow] == 0)//统计无方块个数
                            {
                                space++;
                            }
                        }

                        for (int grow = 0; grow < 10; grow++)
                        {

                            if (grow == j)
                                continue;
                            if (youtu[i, grow] == 0 && newblock < (space / 2))//对于无方块的随机生成,不要生成超过一半空位
                            {

                                Random r = new Random();
                                byte[] buffer = Guid.NewGuid().ToByteArray();
                                iSeed = BitConverter.ToInt32(buffer, 0);
                                r = new Random(iSeed);

                                youtu[i, grow] = r.Next(0, 2);
                                if (youtu[i, grow] == 1)
                                    newblock++;

                            }
                        }
                    }
                }

            }
            iSeed = 0;
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (P2youtu[i, j] == 2)//有爆炸方块，随机消除这一排
                    {
                        P2youtu[i, j] = 1;//先变回普通方块
                        for (int boom = 0; boom < 10; boom++)
                        {
                            if (boom == j)
                                continue;
                            if (P2youtu[i, boom] == 1)//对于有方块的随机消除
                            {
                                Random r = new Random();
                                byte[] buffer = Guid.NewGuid().ToByteArray();
                                iSeed = BitConverter.ToInt32(buffer, 0);
                                r = new Random(iSeed);
                                P2youtu[i, boom] = r.Next(0, 2);
                            }
                        }
                    }
                    if (P2youtu[i, j] == 3)//有生长方块
                    {
                        P2youtu[i, j] = 1;//先变回普通方块
                        int space = 0;
                        int newblock = 0;
                        for (int grow = 0; grow < 10; grow++)
                        {
                            if (P2youtu[i, grow] == 0)//统计无方块个数
                            {
                                space++;
                            }
                        }

                        for (int grow = 0; grow < 10; grow++)
                        {

                            if (grow == j)
                                continue;
                            if (P2youtu[i, grow] == 0 && newblock < (space / 2))//对于无方块的随机生成,不要生成超过一半空位
                            {

                                Random r = new Random();
                                byte[] buffer = Guid.NewGuid().ToByteArray();
                                iSeed = BitConverter.ToInt32(buffer, 0);
                                r = new Random(iSeed);

                                P2youtu[i, grow] = r.Next(0, 2);
                                if (P2youtu[i, grow] == 1)
                                    newblock++;

                            }
                        }
                    }
                }

            }
            ///////////////特殊方块处理完毕///////////////////


            int rawcount = 0;
            //////////////判断有没有消掉///////////////////
            for (int i = 0; i < 21; i++)
            {
                int count = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (youtu[i, j] == 1)//有东西
                        count++;
                }
                if (count == 10)//凑齐一排消
                {
                    rawcount++;
                    for (int k = i; k > 0; k--)
                        for (int j = 0; j < 10; j++)
                        {
                            youtu[k, j] = youtu[k - 1, j];
                        }
                }
            }
            if (rawcount == 2 || rawcount == 3)
                while (rawcount-- > 0)
                {
                    for (int i = 1; i < 21; i++)
                    {
                        for (int j = 0; j < 10; j++)
                        {
                            if (P2youtu[i, j] == 1)
                            {
                                P2youtu[i - 1, j] = P2youtu[i, j];
                                P2youtu[i, j] = 0;
                            }
                        }
                    }
                    Random r = new Random();
                    byte[] buffer = Guid.NewGuid().ToByteArray();
                    iSeed = BitConverter.ToInt32(buffer, 0);
                    r = new Random(iSeed);
                    int kong = r.Next(0, 10);
                    for (int j = 0; j < 10; j++)
                    {
                        if (j == kong)
                            P2youtu[20, j] = 0;
                        else
                            P2youtu[20, j] = 1;
                    }

                }
            else if (rawcount == 4)
            {
                Random r = new Random();
                byte[] buffer = Guid.NewGuid().ToByteArray();
                iSeed = BitConverter.ToInt32(buffer, 0);
                r = new Random(iSeed);
                P2specialtype = r.Next(1, 3);
            }
            ///////////////////////////////P2对P1//////////////
            rawcount = 0;
            for (int i = 0; i < 21; i++)
            {
                int count = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (P2youtu[i, j] == 1)//有东西
                        count++;
                }
                if (count == 10)//凑齐一排消
                {
                    rawcount++;
                    for (int k = i; k > 0; k--)
                        for (int j = 0; j < 10; j++)
                        {
                            P2youtu[k, j] = P2youtu[k - 1, j];
                        }
                }
            }
            if (rawcount == 2 || rawcount == 3)
                while (rawcount-- > 0)
                {
                    for (int i = 1; i < 21; i++)
                    {
                        for (int j = 0; j < 10; j++)
                        {
                            if (youtu[i, j] == 1)
                            {
                                youtu[i - 1, j] = youtu[i, j];
                                youtu[i, j] = 0;
                            }
                        }
                    }
                    Random r = new Random();
                    byte[] buffer = Guid.NewGuid().ToByteArray();
                    iSeed = BitConverter.ToInt32(buffer, 0);
                    r = new Random(iSeed);
                    int kong = r.Next(0, 10);
                    for (int j = 0; j < 10; j++)
                    {
                        if (j == kong)
                            youtu[20, j] = 0;
                        else
                            youtu[20, j] = 1;
                    }

                }
            else if (rawcount == 4)
            {
                Random r = new Random();
                byte[] buffer = Guid.NewGuid().ToByteArray();
                iSeed = BitConverter.ToInt32(buffer, 0);
                r = new Random(iSeed);
                specialtype = r.Next(1, 3);
            }
            //////////////判断消除完毕//////////////////
            //////////////////////////////实时生成新背景///////////////////////////
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (youtu[i, j] == 1)
                    {
                        P1pen.Color = Color.RoyalBlue;
                        P1brush.Color = Color.SlateBlue;
                        P1nbg.DrawRectangle(P1pen, j * size, i * size, size, size);
                        P1nbg.FillRectangle(P1brush, j * size + 2, i * size + 2, size - 3, size - 3);
                    }
                }
            }
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (P2youtu[i, j] == 1)
                    {
                        P2pen.Color = Color.RoyalBlue;
                        P2brush.Color = Color.SlateBlue;
                        P2nbg.DrawRectangle(P2pen, j * size, i * size, size, size);
                        P2nbg.FillRectangle(P2brush, j * size + 2, i * size + 2, size - 3, size - 3);
                    }
                }
            }
            //////////////////////////实时生成新背景结束///////////////////////////
            pictureBox1.Image = P1image; //前景
            pictureBox1.BackgroundImage = P1newcanvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
            pictureBox1.Refresh();
            
            pictureBox2.Image = P2image; //前景
            pictureBox2.BackgroundImage = P2newcanvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
            pictureBox2.Refresh();


            if (youtu[0, 4] == 1 || youtu[0, 5] == 1 || P2youtu[0, 4] == 1 || P2youtu[0, 5] == 1)
            {

                timer2.Stop();
                MessageBox.Show("游戏结束");
            }
            else
            {
                timer2.Start();
            }
        
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            speed++;
            if (speed > 60*level&&level<3)
            {
                level++;
                speed = 0;
                timer1.Interval = timer1.Interval/2;
                label1.Text = "速度:" + level;
            }
            // 初始化前景图片画布
            Bitmap image = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            // 初始化整个画布
            Bitmap newcanvas = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap canvas = (Bitmap)pictureBox1.BackgroundImage;
            // 初始化图形面板
            Graphics g = Graphics.FromImage(image);
            Graphics bg = Graphics.FromImage(canvas);
            Graphics nbg = Graphics.FromImage(newcanvas);//如有一行消除 则在这个上面重新绘制方块
            // 绘图部分 Begin
            //Graphics gra = pictureBox1.CreateGraphics();//将图形画在PictureBox控件
            Pen pen = new Pen(Color.Red, 2);
            Pen greypen = new Pen(Color.Gray, 2);
            SolidBrush brush = new SolidBrush(Color.Coral);
            if (specialtype == 1)
            {
                pen.Color = Color.Red;
                brush.Color = Color.Coral;
            }
            else if (specialtype == 2)
            {
                pen.Color = Color.MediumSeaGreen;
                brush.Color = Color.LimeGreen;
            }
            else
            {
                pen.Color = Color.RoyalBlue;
                brush.Color = Color.SlateBlue;
            }
            //判断添加下落预判图  
            bool predict = false;
            int predictcount = 0;
            int predictx1 = x1, predictx2 = x2, predictx3 = x3, predictx4 = x4, predicty1 = y1, predicty2 = y2, predicty3 = y3, predicty4 = y4;
            while (!predict)
            {
                predictcount++;
                if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                {
                    if (predictcount != 1)
                    {
                        g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                        g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                        g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                        g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                    }
                    predict = true;
                }
                else //进行碰撞计算再绘图
                {
                    if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                    {
                        if (youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (youtu[predicty2 / size + 1, predictx2 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (youtu[predicty3 / size + 1, predictx3 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    if (predict == false)
                    {
                        if (youtu[predicty4 / size + 1, predictx4 / size] == 0)
                            predict = false;
                        else
                            predict = true;
                    }
                    //下落碰撞检测完毕
                    if (predict == false)//没有发生碰撞，下落
                    {
                        predicty1 = predicty1 + size;
                        predicty2 = predicty2 + size;
                        predicty3 = predicty3 + size;
                        predicty4 = predicty4 + size;
                    }
                    else
                    {
                        if (predictcount != 1)
                        {
                            g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                            g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                            g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                            g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                        }
                        predict = true;
                    }
                }
            }


            bool meet = false;//判断下落是否碰撞
            if(y1/size>19||y2/size>19||y3/size>19||y4/size>19) //下落到最低，直接绘图，不用计算碰撞
            {
                if (specialtype == 1)
                {
                    youtu[y1 / size, x1 / size] = 2;
                    youtu[y2 / size, x2 / size] = 2;
                    youtu[y3 / size, x3 / size] = 2;
                    youtu[y4 / size, x4 / size] = 2;
                }
                else if (specialtype == 2)
                {
                    youtu[y1 / size, x1 / size] = 3;
                    youtu[y2 / size, x2 / size] = 3;
                    youtu[y3 / size, x3 / size] = 3;
                    youtu[y4 / size, x4 / size] = 3;
                }
                else
                {
                    youtu[y1 / size, x1 / size] = 1;
                    youtu[y2 / size, x2 / size] = 1;
                    youtu[y3 / size, x3 / size] = 1;
                    youtu[y4 / size, x4 / size] = 1;
                }
                
                bg.DrawRectangle(pen, x1, y1, size, size);
                bg.DrawRectangle(pen, x2, y2 , size, size);
                bg.DrawRectangle(pen, x3, y3, size, size);
                bg.DrawRectangle(pen, x4, y4, size, size);
                bg.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                bg.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                bg.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                bg.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                
                block_init(ref type,ref turn);
                special_init(ref specialtype);
                if (specialtype == 1)
                {
                    pen.Color = Color.Red;
                    brush.Color = Color.Coral;
                }
                else if (specialtype == 2)
                {
                    pen.Color = Color.MediumSeaGreen;
                    brush.Color = Color.LimeGreen;
                }
                else
                {
                    pen.Color = Color.RoyalBlue;
                    brush.Color = Color.SlateBlue;
                }
                g.DrawRectangle(pen, x1, y1, size, size);
                g.DrawRectangle(pen, x2, y2, size, size);
                g.DrawRectangle(pen, x3, y3, size, size);
                g.DrawRectangle(pen, x4, y4, size, size);
                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
            }
            else //进行碰撞计算再绘图
            {
                if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                {
                    if (youtu[y1 / size + 1, x1 / size] == 0)//大坐标转换为数组对应值
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (youtu[y2 / size + 1, x2 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (youtu[y3 / size + 1, x3 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                if (meet == false)
                {
                    if (youtu[y4 / size + 1, x4 / size] == 0)
                        meet = false;
                    else
                        meet = true;
                }
                //下落碰撞检测完毕
                if (meet == false)//没有发生碰撞，下落
                {
                    y1 = y1 + size;
                    y2 = y2 + size;
                    y3 = y3 + size;
                    y4 = y4 + size;
                    g.DrawRectangle(pen, x1, y1, size, size);
                    g.DrawRectangle(pen, x2, y2, size, size);
                    g.DrawRectangle(pen, x3, y3, size, size);
                    g.DrawRectangle(pen, x4, y4, size, size);
                    g.FillRectangle(brush, x1+2, y1+2, size-3, size-3);
                    g.FillRectangle(brush, x2+2, y2+2, size-3, size-3);
                    g.FillRectangle(brush, x3+2, y3+2, size-3, size-3);
                    g.FillRectangle(brush, x4+2, y4+2, size-3, size-3);
                }
                else
                {
                    if (specialtype == 1)
                    {
                        youtu[y1 / size, x1 / size] = 2;
                        youtu[y2 / size, x2 / size] = 2;
                        youtu[y3 / size, x3 / size] = 2;
                        youtu[y4 / size, x4 / size] = 2;
                    }
                    else if (specialtype == 2)
                    {
                        youtu[y1 / size, x1 / size] = 3;
                        youtu[y2 / size, x2 / size] = 3;
                        youtu[y3 / size, x3 / size] = 3;
                        youtu[y4 / size, x4 / size] = 3;
                    }
                    else
                    {
                        youtu[y1 / size, x1 / size] = 1;
                        youtu[y2 / size, x2 / size] = 1;
                        youtu[y3 / size, x3 / size] = 1;
                        youtu[y4 / size, x4 / size] = 1;
                    }


                    bg.DrawRectangle(pen, x1, y1, size, size);
                    bg.DrawRectangle(pen, x2, y2, size, size);
                    bg.DrawRectangle(pen, x3, y3, size, size);
                    bg.DrawRectangle(pen, x4, y4, size, size);
                    bg.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                    bg.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                    bg.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                    bg.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                    
                    block_init(ref type, ref turn);
                    special_init(ref specialtype);
                    if (specialtype == 1)
                    {
                        pen.Color = Color.Red;
                        brush.Color = Color.Coral;
                    }
                    else if (specialtype == 2)
                    {
                        pen.Color = Color.MediumSeaGreen;
                        brush.Color = Color.LimeGreen;
                    }
                    else
                    {
                        pen.Color = Color.RoyalBlue;
                        brush.Color = Color.SlateBlue;
                    }
                    g.DrawRectangle(pen, x1, y1, size, size);
                    g.DrawRectangle(pen, x2, y2, size, size);
                    g.DrawRectangle(pen, x3, y3, size, size);
                    g.DrawRectangle(pen, x4, y4, size, size);
                    g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                    g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                    g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                    g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                }
            }
           

            //下落碰撞检测完毕
            //判断有没有特殊方块
            int iSeed = 0;
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (youtu[i, j] == 2)//有爆炸方块，随机消除这一排


                    {
                        youtu[i, j] = 1;//先变回普通方块
                        for (int boom = 0; boom < 10; boom++)
                        {
                            if (boom == j)
                                continue;
                            if (youtu[i, boom] == 1)//对于有方块的随机消除
                            {
                                Random r = new Random();
                                byte[] buffer = Guid.NewGuid().ToByteArray();
                                iSeed = BitConverter.ToInt32(buffer, 0);
                                r = new Random(iSeed);

                                youtu[i, boom] = r.Next(0, 2);
                            }
                        }
                    }
                    if (youtu[i, j] == 3)//有生长方块
                    {
                        youtu[i, j] = 1;//先变回普通方块
                        int space = 0;
                        int newblock = 0;
                        for (int grow = 0; grow < 10; grow++)
                        {
                            if (youtu[i, grow] == 0)//统计无方块个数
                            {
                                space++;
                            }
                        }
                       
                        for (int grow = 0; grow < 10; grow++)
                        {

                            if (grow == j)
                                continue;
                            if (youtu[i, grow] == 0&&newblock<(space/2))//对于无方块的随机生成,不要生成超过一半空位
                            {

                                Random r = new Random();
                                byte[] buffer = Guid.NewGuid().ToByteArray();
                                iSeed = BitConverter.ToInt32(buffer, 0);
                                r = new Random(iSeed);
                                
                                youtu[i, grow] = r.Next(0, 2);
                                if (youtu[i, grow] == 1)
                                    newblock++;
                                    
                            }
                        }
                    }
                }
               
            }
            //特殊方块处理完毕
            
            for (int i = 0; i < 21; i++)//判断有没有消掉
            {
                int count = 0;
                for (int j = 0; j < 10; j++)
                {
                    if (youtu[i, j] == 1)//有东西
                        count++;
                }
                if (count == 10)//凑齐一排消
                {
                   
                    for (int k = i; k > 0; k--)
                        for (int j = 0; j < 10; j++)
                        {
                            youtu[k, j] = youtu[k - 1, j];
                        }
                }
            }

           
            for (int i = 0; i < 21; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (youtu[i, j] == 1)
                    {
                        pen.Color = Color.RoyalBlue;
                        brush.Color = Color.SlateBlue;
                        nbg.DrawRectangle(pen, j * size, i * size, size, size);
                        nbg.FillRectangle(brush, j * size + 2, i * size + 2, size - 3, size - 3);
                    }

                }
            }
            pictureBox1.Image = image; //前景
            pictureBox1.BackgroundImage = newcanvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
            pictureBox1.Refresh();

           
            if (youtu[0, 4] == 1 || youtu[0, 5] == 1)
            {
               
                timer1.Stop();
                MessageBox.Show("游戏结束");
            }
            else
            {
                timer1.Start();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true); // 禁止擦除背景.
            SetStyle(ControlStyles.DoubleBuffer, true); // 双缓冲

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }



        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)

        {
            bool meet = false;//判断碰撞
            // 初始化前景图片画布
            Bitmap image = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);

            // 初始化整个画布
            //Bitmap canvas = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap canvas = (Bitmap)pictureBox1.BackgroundImage;
            // 初始化图形面板
            Graphics g = Graphics.FromImage(image);
            Graphics bg = Graphics.FromImage(canvas);
            // 绘图部分 Begin
            //Graphics gra = pictureBox1.CreateGraphics();//将图形画在PictureBox控件
            Pen pen = new Pen(Color.Red, 2);
            Pen greypen = new Pen(Color.Gray, 2);
            SolidBrush brush = new SolidBrush(Color.Coral);

            Bitmap P2image = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            Bitmap P2canvas;
            if (!onlyone)
            {
                P2canvas = (Bitmap)pictureBox2.BackgroundImage;
            }
            // 初始化整个画布
            //Bitmap canvas = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            else
            {
               P2canvas = (Bitmap)pictureBox1.BackgroundImage;
            }
            // 初始化图形面板
            Graphics P2g = Graphics.FromImage(P2image);
            Graphics P2bg = Graphics.FromImage(P2canvas);
            // 绘图部分 Begin
            //Graphics gra = pictureBox1.CreateGraphics();//将图形画在PictureBox控件
            Pen P2pen = new Pen(Color.Red, 2);
            Pen P2greypen = new Pen(Color.Gray, 2);
            SolidBrush P2brush = new SolidBrush(Color.Coral);
            if (specialtype == 1)
            {
                pen.Color = Color.Red;
                brush.Color = Color.Coral;
            }
            else if (specialtype == 2)
            {
                pen.Color = Color.MediumSeaGreen;
                brush.Color = Color.LimeGreen;
            }
            else
            {
                pen.Color = Color.RoyalBlue;
                brush.Color = Color.SlateBlue;
            }

            if (P2specialtype == 1)
            {
                P2pen.Color = Color.Red;
                P2brush.Color = Color.Coral;
            }
            else if (P2specialtype == 2)
            {
                P2pen.Color = Color.MediumSeaGreen;
                P2brush.Color = Color.LimeGreen;
            }
            else
            {
                P2pen.Color = Color.RoyalBlue;
                P2brush.Color = Color.SlateBlue;
            }

            switch (keyData)

            {

                case Keys.Right:
                    if (y1 >= 0 && y2 >= 0 && y3 >= 0 && y4 >= 0)
                    {
                        meet = false;//判断右是否能移动
                        if (x1 / size + 1 > 9 || x2 / size + 1 > 9 ||
                             x3 / size + 1 > 9 || x4 / size + 1 > 9) //碰到左右边界，不能移动
                        {
                            g.DrawRectangle(pen, x1, y1, size, size);
                            g.DrawRectangle(pen, x2, y2, size, size);
                            g.DrawRectangle(pen, x3, y3, size, size);
                            g.DrawRectangle(pen, x4, y4, size, size);
                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                            pictureBox1.Image = image; //前景
                            pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                        }
                        else //进行碰撞计算再绘图
                        {
                            if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能右移
                            {
                                if (youtu[y1 / size, x1 / size + 1] == 0)//大坐标转换为数组对应值
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y2 / size, x2 / size + 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y3 / size, x3 / size + 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y4 / size, x4 / size + 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            //右移碰撞检测完毕
                            if (meet == false)//没有发生碰撞，右移动
                            {
                                x1 = x1 + size;
                                x2 = x2 + size;
                                x3 = x3 + size;
                                x4 = x4 + size;
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                pictureBox1.Image = image; //前景
                                pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                            else//右移会碰撞，不能移动
                            {
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                pictureBox1.Image = image; //前景
                                pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                        }
                    }
                    //判断添加下落预判图  
                    bool predict = false;
                    int predictcount = 0;
                    int predictx1 = x1, predictx2 = x2, predictx3 = x3, predictx4 = x4, predicty1 = y1, predicty2 = y2, predicty3 = y3, predicty4 = y4;
                    while (!predict)
                    {
                        predictcount++;
                        if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {
                            if (predictcount != 1)
                            {
                                g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                            }
                            predict = true;
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            //下落碰撞检测完毕
                            if (predict == false)//没有发生碰撞，下落
                            {
                                predicty1 = predicty1 + size;
                                predicty2 = predicty2 + size;
                                predicty3 = predicty3 + size;
                                predicty4 = predicty4 + size;
                            }
                            else
                            {
                                if (predictcount != 1)
                                {
                                    g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                    g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                    g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                    g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                        }
                    }



                    break;


                case Keys.Left:
                    if (y1 >= 0 && y2 >= 0)
                    {
                        meet = false;//判断左是否能移动
                        if (x1 / size - 1 < 0 || x2 / size - 1 < 0 || x3 / size - 1 < 0 || x4 / size - 1 < 0)  //碰到左右边界，不能移动
                        {
                            g.DrawRectangle(pen, x1, y1, size, size);
                            g.DrawRectangle(pen, x2, y2, size, size);
                            g.DrawRectangle(pen, x3, y3, size, size);
                            g.DrawRectangle(pen, x4, y4, size, size);
                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                            pictureBox1.Image = image; //前景
                            pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                        }
                        else //进行碰撞计算再绘图
                        {
                            if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能左移
                            {
                                if (youtu[y1 / size, x1 / size - 1] == 0)//大坐标转换为数组对应值
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y2 / size, x2 / size - 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y3 / size, x3 / size - 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y4 / size, x4 / size - 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            //左移碰撞检测完毕
                            if (meet == false)//没有发生碰撞，左移动
                            {
                                x1 = x1 - size;
                                x2 = x2 - size;
                                x3 = x3 - size;
                                x4 = x4 - size;
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                pictureBox1.Image = image; //前景
                                pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                            else//左移会碰撞，不能移动
                            {
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                pictureBox1.Image = image; //前景
                                pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                        }



                    }
                    //判断添加下落预判图  
                    predict = false;
                    predictcount = 0;
                    predictx1 = x1; predictx2 = x2; predictx3 = x3; predictx4 = x4; predicty1 = y1; predicty2 = y2; predicty3 = y3; predicty4 = y4;
                    while (!predict)
                    {
                        predictcount++;
                        if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {
                            if (predictcount != 1)
                            {
                                g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                            }
                            predict = true;
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            //下落碰撞检测完毕
                            if (predict == false)//没有发生碰撞，下落
                            {
                                predicty1 = predicty1 + size;
                                predicty2 = predicty2 + size;
                                predicty3 = predicty3 + size;
                                predicty4 = predicty4 + size;
                            }
                            else
                            {
                                if (predictcount != 1)
                                {
                                    g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                    g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                    g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                    g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                        }
                    }
                    //画图
                    pictureBox1.Image = image; //前景
                    pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
                    pictureBox1.Refresh();
                    break;

                case Keys.Up://方向键不反应
                    {
                        int tempx1, tempx2, tempx3, tempx4, tempy1, tempy2, tempy3, tempy4;//临时存放旋转前的图形，不能旋转就变回来
                        switch (type)
                        {
                            case 0://田字型不会变形
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                break;
                            case 1:
                                {
                                    switch (turn)
                                    {
                                        case 0:
                                            turn0_long_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4,youtu);
                                            if (meet)
                                            {
                                                turn1_long_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            }

                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            turn1_long_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4,youtu);//判断旋转后左右是否碰撞
                                            if (meet)
                                            {
                                                turn0_long_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;



                                    }
                                    break;
                                }
                            case 2:
                                {
                                    switch (turn)
                                    {
                                        case 0:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn0_tublock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn1_tublock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 2:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn2_tublock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 3:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn3_tublock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    switch (turn)
                                    {
                                        case 0:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn0_RZblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn1_RZblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    switch (turn)
                                    {
                                        case 0:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn0_LZblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn1_LZblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    switch (turn)
                                    {
                                        case 0:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn0_LLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn1_LLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 2:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn2_LLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 3:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn3_LLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    switch (turn)
                                    {
                                        case 0:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn0_RLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn1_RLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 2:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn2_RLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                        case 3:
                                            tempx1 = x1; tempx2 = x2; tempx3 = x3; tempx4 = x4;
                                            tempy1 = y1; tempy2 = y2; tempy3 = y3; tempy4 = y4;
                                            turn3_RLblock_init(ref x1, ref x2, ref y1, ref y2, ref x3, ref x4, ref y3, ref y4, ref turn);
                                            meet = meetnow(x1, x2, x3, x4, y1, y2, y3, y4, youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x1 = tempx1; x2 = tempx2; x3 = tempx3; x4 = tempx4;
                                                y1 = tempy1; y2 = tempy2; y3 = tempy3; y4 = tempy4;
                                            }
                                            g.DrawRectangle(pen, x1, y1, size, size);
                                            g.DrawRectangle(pen, x2, y2, size, size);
                                            g.DrawRectangle(pen, x3, y3, size, size);
                                            g.DrawRectangle(pen, x4, y4, size, size);
                                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;

                                }
                        }

                        //判断添加下落预判图  
                        predict = false;
                        predictcount = 0;
                        predictx1 = x1; predictx2 = x2; predictx3 = x3; predictx4 = x4; predicty1 = y1; predicty2 = y2; predicty3 = y3; predicty4 = y4;
                        while (!predict)
                        {
                            predictcount++;
                            if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                            {
                                if (predictcount != 1)
                                {
                                    g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                    g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                    g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                    g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                            else //进行碰撞计算再绘图
                            {
                                if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                                {
                                    if (youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                if (predict == false)
                                {
                                    if (youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                if (predict == false)
                                {
                                    if (youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                if (predict == false)
                                {
                                    if (youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                //下落碰撞检测完毕
                                if (predict == false)//没有发生碰撞，下落
                                {
                                    predicty1 = predicty1 + size;
                                    predicty2 = predicty2 + size;
                                    predicty3 = predicty3 + size;
                                    predicty4 = predicty4 + size;
                                }
                                else
                                {
                                    if (predictcount != 1)
                                    {
                                        g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                        g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                        g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                        g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                                    }
                                    predict = true;
                                }
                            }
                        }
                        //画图
                        pictureBox1.Image = image; //前景
                        pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
                        pictureBox1.Refresh();
                        break;
                    }

                case Keys.Down:
                    if (y1 >= 0 && y2 >= 0)
                    {
                        meet = false;//判断下落是否碰撞
                        if (y1 / size > 19 || y2 / size > 19 || y3 / size > 19 || y4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {

                            if (specialtype == 1)
                            {
                                youtu[y1 / size, x1 / size] = 2;
                                youtu[y2 / size, x2 / size] = 2;
                                youtu[y3 / size, x3 / size] = 2;
                                youtu[y4 / size, x4 / size] = 2;
                            }
                            else if (specialtype == 2)
                            {
                                youtu[y1 / size, x1 / size] = 3;
                                youtu[y2 / size, x2 / size] = 3;
                                youtu[y3 / size, x3 / size] = 3;
                                youtu[y4 / size, x4 / size] = 3;
                            }
                            else
                            {
                                youtu[y1 / size, x1 / size] = 1;
                                youtu[y2 / size, x2 / size] = 1;
                                youtu[y3 / size, x3 / size] = 1;
                                youtu[y4 / size, x4 / size] = 1;
                            }
                            bg.DrawRectangle(pen, x1, y1, size, size);
                            bg.DrawRectangle(pen, x2, y2, size, size);
                            bg.DrawRectangle(pen, x3, y3, size, size);
                            bg.DrawRectangle(pen, x4, y4, size, size);
                            bg.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                            bg.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                            bg.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                            bg.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                            
                            block_init(ref type, ref turn);
                            if (onlyone == true)
                                special_init(ref specialtype);
                            if (specialtype == 1)
                            {
                                pen.Color = Color.Red;
                                brush.Color = Color.Coral;
                            }
                            else if (specialtype == 2)
                            {
                                pen.Color = Color.MediumSeaGreen;
                                brush.Color = Color.LimeGreen;
                            }
                            else
                            {
                                pen.Color = Color.RoyalBlue;
                                brush.Color = Color.SlateBlue;
                            }
                            g.DrawRectangle(pen, x1, y1, size, size);
                            g.DrawRectangle(pen, x2, y2, size, size);
                            g.DrawRectangle(pen, x3, y3, size, size);
                            g.DrawRectangle(pen, x4, y4, size, size);
                            g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                            g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (youtu[y1 / size + 1, x1 / size] == 0)//大坐标转换为数组对应值
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y2 / size + 1, x2 / size] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y3 / size + 1, x3 / size] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (youtu[y4 / size + 1, x4 / size] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            //下落碰撞检测完毕
                            if (meet == false)//没有发生碰撞，下落
                            {
                                y1 = y1 + size;
                                y2 = y2 + size;
                                y3 = y3 + size;
                                y4 = y4 + size;
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                            }
                            else
                            {
                                if (specialtype == 1)
                                {
                                    youtu[y1 / size, x1 / size] = 2;
                                    youtu[y2 / size, x2 / size] = 2;
                                    youtu[y3 / size, x3 / size] = 2;
                                    youtu[y4 / size, x4 / size] = 2;
                                }
                                else if (specialtype == 2)
                                {
                                    youtu[y1 / size, x1 / size] = 3;
                                    youtu[y2 / size, x2 / size] = 3;
                                    youtu[y3 / size, x3 / size] = 3;
                                    youtu[y4 / size, x4 / size] = 3;
                                }
                                else
                                {
                                    youtu[y1 / size, x1 / size] = 1;
                                    youtu[y2 / size, x2 / size] = 1;
                                    youtu[y3 / size, x3 / size] = 1;
                                    youtu[y4 / size, x4 / size] = 1;
                                }
                                //y1 = y1 + size;
                                //y2 = y2 + size;
                                bg.DrawRectangle(pen, x1, y1, size, size);
                                bg.DrawRectangle(pen, x2, y2, size, size);
                                bg.DrawRectangle(pen, x3, y3, size, size);
                                bg.DrawRectangle(pen, x4, y4, size, size);
                                bg.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                bg.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                bg.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                bg.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                                
                                block_init(ref type, ref turn);
                                if (onlyone == true)
                                    special_init(ref specialtype);
                                if (specialtype == 1)
                                {
                                    pen.Color = Color.Red;
                                    brush.Color = Color.Coral;
                                }
                                else if (specialtype == 2)
                                {
                                    pen.Color = Color.MediumSeaGreen;
                                    brush.Color = Color.LimeGreen;
                                }
                                else
                                {
                                    pen.Color = Color.RoyalBlue;
                                    brush.Color = Color.SlateBlue;
                                }
                                g.DrawRectangle(pen, x1, y1, size, size);
                                g.DrawRectangle(pen, x2, y2, size, size);
                                g.DrawRectangle(pen, x3, y3, size, size);
                                g.DrawRectangle(pen, x4, y4, size, size);
                                g.FillRectangle(brush, x1 + 2, y1 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x2 + 2, y2 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x3 + 2, y3 + 2, size - 3, size - 3);
                                g.FillRectangle(brush, x4 + 2, y4 + 2, size - 3, size - 3);
                            }
                        }


                    }
                    //判断添加下落预判图  
                    predict = false;
                    predictcount = 0;
                    predictx1 = x1; predictx2 = x2; predictx3 = x3; predictx4 = x4; predicty1 = y1; predicty2 = y2; predicty3 = y3; predicty4 = y4;
                    while (!predict)
                    {
                        predictcount++;
                        if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {
                            if (predictcount != 1)
                            {
                                g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                            }
                            predict = true;
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            //下落碰撞检测完毕
                            if (predict == false)//没有发生碰撞，下落
                            {
                                predicty1 = predicty1 + size;
                                predicty2 = predicty2 + size;
                                predicty3 = predicty3 + size;
                                predicty4 = predicty4 + size;
                            }
                            else
                            {
                                if (predictcount != 1)
                                {
                                    g.DrawRectangle(greypen, predictx1, predicty1, size, size);
                                    g.DrawRectangle(greypen, predictx2, predicty2, size, size);
                                    g.DrawRectangle(greypen, predictx3, predicty3, size, size);
                                    g.DrawRectangle(greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                        }
                    }
                    //画图
                    pictureBox1.Image = image; //前景
                    pictureBox1.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
                    pictureBox1.Refresh();
                    break;
                case Keys.Space:

                    MessageBox.Show("space");

                    break;

                case Keys.Enter:

                    MessageBox.Show("enter");

                    break;


                ///////////////////////////p2玩家操作/////////////
                case Keys.D:

                    if (P2specialtype == 1)
                    {
                        P2pen.Color = Color.Red;
                        P2brush.Color = Color.Coral;
                    }
                    else if (P2specialtype == 2)
                    {
                        P2pen.Color = Color.MediumSeaGreen;
                        P2brush.Color = Color.LimeGreen;
                    }
                    else
                    {
                        P2pen.Color = Color.RoyalBlue;
                        P2brush.Color = Color.SlateBlue;
                    }
                    if (y5 >= 0 && y6 >= 0 && y7 >= 0 && y8 >= 0)
                    {
                        meet = false;//判断右是否能移动
                        if (x5 / size + 1 > 9 || x6 / size + 1 > 9 ||
                             x7 / size + 1 > 9 || x8 / size + 1 > 9) //碰到左右边界，不能移动
                        {
                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                            pictureBox2.Image = image; //前景
                            pictureBox2.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                        }
                        else //进行碰撞计算再绘图
                        {
                            if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能右移
                            {
                                if (P2youtu[y5 / size, x5 / size + 1] == 0)//大坐标转换为数组对应值
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y6 / size, x6 / size + 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y7 / size, x7 / size + 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y8 / size, x8 / size + 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            //右移碰撞检测完毕
                            if (meet == false)//没有发生碰撞，右移动
                            {
                                x5 = x5 + size;
                                x6 = x6 + size;
                                x7 = x7 + size;
                                x8 = x8 + size;
                                P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                pictureBox2.Image = image; //前景
                                pictureBox2.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                            else//右移会碰撞，不能移动
                            {
                                P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                pictureBox2.Image = image; //前景
                                pictureBox2.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                        }
                    }
                    //判断添加下落预判图  
                    predict = false;
                    predictcount = 0;
                    predictx1 = x5; predictx2 = x6; predictx3 = x7; predictx4 = x8; predicty1 = y5; predicty2 = y6; predicty3 = y7; predicty4 = y8;
                    while (!predict)
                    {
                        predictcount++;
                        if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {
                            if (predictcount != 1)
                            {
                                P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                            }
                            predict = true;
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (P2youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            //下落碰撞检测完毕
                            if (predict == false)//没有发生碰撞，下落
                            {
                                predicty1 = predicty1 + size;
                                predicty2 = predicty2 + size;
                                predicty3 = predicty3 + size;
                                predicty4 = predicty4 + size;
                            }
                            else
                            {
                                if (predictcount != 1)
                                {
                                    P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                        }
                    }
                    pictureBox2.Image = P2image; //前景
                    pictureBox2.BackgroundImage = P2canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布
                   

                    break;
                case Keys.A:

                    if (P2specialtype == 1)
                    {
                        P2pen.Color = Color.Red;
                        P2brush.Color = Color.Coral;
                    }
                    else if (P2specialtype == 2)
                    {
                        P2pen.Color = Color.MediumSeaGreen;
                        P2brush.Color = Color.LimeGreen;
                    }
                    else
                    {
                        P2pen.Color = Color.RoyalBlue;
                        P2brush.Color = Color.SlateBlue;
                    }
                    if (y5 >= 0 && y6 >= 0 && y7 >= 0 && y8 >= 0)
                    {
                        meet = false;//判断右是否能移动
                        if (x5 / size - 1 < 0 || x6 / size - 1 < 0 ||
                             x7 / size - 1 < 0 || x8 / size - 1 < 0) //碰到左右边界，不能移动
                        {
                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                            pictureBox2.Image = image; //前景
                            pictureBox2.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                        }
                        else //进行碰撞计算再绘图
                        {
                            if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能右移
                            {
                                if (P2youtu[y5 / size, x5 / size - 1] == 0)//大坐标转换为数组对应值
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y6 / size, x6 / size - 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y7 / size, x7 / size - 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y8 / size, x8 / size - 1] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            //右移碰撞检测完毕
                            if (meet == false)//没有发生碰撞，右移动
                            {
                                x5 = x5 - size;
                                x6 = x6 - size;
                                x7 = x7 - size;
                                x8 = x8 - size;
                                P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                pictureBox2.Image = image; //前景
                                pictureBox2.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                            else//右移会碰撞，不能移动
                            {
                                P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                pictureBox2.Image = image; //前景
                                pictureBox2.BackgroundImage = canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布

                            }
                        }
                    }
                    //判断添加下落预判图  
                    predict = false;
                    predictcount = 0;
                    predictx1 = x5; predictx2 = x6; predictx3 = x7; predictx4 = x8; predicty1 = y5; predicty2 = y6; predicty3 = y7; predicty4 = y8;
                    while (!predict)
                    {
                        predictcount++;
                        if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {
                            if (predictcount != 1)
                            {
                                P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                            }
                            predict = true;
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (P2youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            //下落碰撞检测完毕
                            if (predict == false)//没有发生碰撞，下落
                            {
                                predicty1 = predicty1 + size;
                                predicty2 = predicty2 + size;
                                predicty3 = predicty3 + size;
                                predicty4 = predicty4 + size;
                            }
                            else
                            {
                                if (predictcount != 1)
                                {
                                    P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                        }
                    }
                    pictureBox2.Image = P2image; //前景
                    pictureBox2.BackgroundImage = P2canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布


                    break;
                case Keys.S:

                    if (P2specialtype == 1)
                    {
                        P2pen.Color = Color.Red;
                        P2brush.Color = Color.Coral;
                    }
                    else if (P2specialtype == 2)
                    {
                        P2pen.Color = Color.MediumSeaGreen;
                        P2brush.Color = Color.LimeGreen;
                    }
                    else
                    {
                        P2pen.Color = Color.RoyalBlue;
                        P2brush.Color = Color.SlateBlue;
                    }
                    if (y5 >= 0 && y6 >= 0 && y7 >= 0 && y8 >= 0)
                    {
                        meet = false;//判断下落是否碰撞
                        if (y5 / size > 19 || y6 / size > 19 || y7 / size > 19 || y8 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {

                            if (P2specialtype == 1)
                            {
                                P2youtu[y5 / size, x5 / size] = 2;
                                P2youtu[y6 / size, x6 / size] = 2;
                                P2youtu[y7 / size, x7 / size] = 2;
                                P2youtu[y8 / size, x8 / size] = 2;
                            }
                            else if (P2specialtype == 2)
                            {
                                P2youtu[y5 / size, x5 / size] = 3;
                                P2youtu[y6 / size, x6 / size] = 3;
                                P2youtu[y7 / size, x7 / size] = 3;
                                P2youtu[y8 / size, x8 / size] = 3;
                            }
                            else
                            {
                                P2youtu[y5 / size, x5 / size] = 1;
                                P2youtu[y6 / size, x6 / size] = 1;
                                P2youtu[y7 / size, x7 / size] = 1;
                                P2youtu[y8 / size, x8 / size] = 1;
                            }
                            P2bg.DrawRectangle(P2pen, x5, y5, size, size);
                            P2bg.DrawRectangle(P2pen, x6, y6, size, size);
                            P2bg.DrawRectangle(P2pen, x7, y7, size, size);
                            P2bg.DrawRectangle(P2pen, x8, y8, size, size);
                            P2bg.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                            P2bg.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                            P2bg.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                            P2bg.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                            
                            
                            P2block_init(ref P2type, ref P2turn);
                            
                            if (P2specialtype == 1)
                            {
                                P2pen.Color = Color.Red;
                                P2brush.Color = Color.Coral;
                            }
                            else if (P2specialtype == 2)
                            {
                                P2pen.Color = Color.MediumSeaGreen;
                                P2brush.Color = Color.LimeGreen;
                            }
                            else
                            {
                                P2pen.Color = Color.RoyalBlue;
                                P2brush.Color = Color.SlateBlue;
                            }
                           P2g.DrawRectangle(P2pen, x5, y5, size, size);
                           P2g.DrawRectangle(P2pen, x6, y6, size, size);
                           P2g.DrawRectangle(P2pen, x7, y7, size, size);
                           P2g.DrawRectangle(P2pen, x8, y8, size, size);
                           P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                           P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                           P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                           P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (meet == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (P2youtu[y5 / size + 1, x5 / size] == 0)//大坐标转换为数组对应值
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y6 / size + 1, x6 / size] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y7 / size + 1, x7 / size] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            if (meet == false)
                            {
                                if (P2youtu[y8 / size + 1, x8 / size] == 0)
                                    meet = false;
                                else
                                    meet = true;
                            }
                            //下落碰撞检测完毕
                            if (meet == false)//没有发生碰撞，下落
                            {
                                y5 = y5 + size;
                                y6 = y6 + size;
                                y7 = y7 + size;
                                y8 = y8 + size;
                               P2g.DrawRectangle(P2pen, x5, y5, size, size);
                               P2g.DrawRectangle(P2pen, x6, y6, size, size);
                               P2g.DrawRectangle(P2pen, x7, y7, size, size);
                               P2g.DrawRectangle(P2pen, x8, y8, size, size);
                               P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                               P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                               P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                               P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                            }
                            else
                            {
                                if (P2specialtype == 1)
                                {
                                    P2youtu[y5 / size, x5 / size] = 2;
                                    P2youtu[y6 / size, x6 / size] = 2;
                                    P2youtu[y7 / size, x7 / size] = 2;
                                    P2youtu[y8 / size, x8 / size] = 2;
                                }
                                else if (P2specialtype == 2)
                                {
                                    P2youtu[y5 / size, x5 / size] = 3;
                                    P2youtu[y6 / size, x6 / size] = 3;
                                    P2youtu[y7 / size, x7 / size] = 3;
                                    P2youtu[y8 / size, x8 / size] = 3;
                                }
                                else
                                {
                                    P2youtu[y5 / size, x5 / size] = 1;
                                    P2youtu[y6 / size, x6 / size] = 1;
                                    P2youtu[y7 / size, x7 / size] = 1;
                                    P2youtu[y8 / size, x8 / size] = 1;
                                }
                                //y5 = y5 + size;
                                //y6 = y6 + size;
                                P2bg.DrawRectangle(P2pen, x5, y5, size, size);
                                P2bg.DrawRectangle(P2pen, x6, y6, size, size);
                                P2bg.DrawRectangle(P2pen, x7, y7, size, size);
                                P2bg.DrawRectangle(P2pen, x8, y8, size, size);
                                P2bg.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                P2bg.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                P2bg.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                P2bg.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                
                                
                                P2block_init(ref P2type, ref P2turn);
                                
                                if (P2specialtype == 1)
                                {
                                    P2pen.Color = Color.Red;
                                    P2brush.Color = Color.Coral;
                                }
                                else if (P2specialtype == 2)
                                {
                                    P2pen.Color = Color.MediumSeaGreen;
                                    P2brush.Color = Color.LimeGreen;
                                }
                                else
                                {
                                    P2pen.Color = Color.RoyalBlue;
                                    P2brush.Color = Color.SlateBlue;
                                }
                               P2g.DrawRectangle(P2pen, x5, y5, size, size);
                               P2g.DrawRectangle(P2pen, x6, y6, size, size);
                               P2g.DrawRectangle(P2pen, x7, y7, size, size);
                               P2g.DrawRectangle(P2pen, x8, y8, size, size);
                               P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                               P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                               P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                               P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                            }
                        }


                    }
                     
                    //判断添加下落预判图  
                    predict = false;
                    predictcount = 0;
                    predictx1 = x5; predictx2 = x6; predictx3 = x7; predictx4 = x8; predicty1 = y5; predicty2 = y6; predicty3 = y7; predicty4 = y8;
                    while (!predict)
                    {
                        predictcount++;
                        if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                        {
                            if (predictcount != 1)
                            {
                                P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                            }
                            predict = true;
                        }
                        else //进行碰撞计算再绘图
                        {
                            if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                            {
                                if (P2youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            if (predict == false)
                            {
                                if (P2youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                    predict = false;
                                else
                                    predict = true;
                            }
                            //下落碰撞检测完毕
                            if (predict == false)//没有发生碰撞，下落
                            {
                                predicty1 = predicty1 + size;
                                predicty2 = predicty2 + size;
                                predicty3 = predicty3 + size;
                                predicty4 = predicty4 + size;
                            }
                            else
                            {
                                if (predictcount != 1)
                                {
                                    P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                        }
                    }
                    pictureBox2.Image = P2image; //前景
                    pictureBox2.BackgroundImage = P2canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布


                    break;
                case Keys.W://方向键不反应
                    {
                        int tempx1, tempx2, tempx3, tempx4, tempy1, tempy2, tempy3, tempy4;//临时存放旋转前的图形，不能旋转就变回来
                        switch (P2type)
                        {
                            case 0://田字型不会变形
                                P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                break;
                            case 1:
                                {
                                    switch (P2turn)
                                    {
                                        case 0:
                                            turn0_long_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);
                                            if (meet)
                                            {
                                                turn1_long_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            }

                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            turn1_long_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转后左右是否碰撞
                                            if (meet)
                                            {
                                                turn0_long_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;



                                    }
                                    break;
                                }
                            case 2:
                                {
                                    switch (P2turn)
                                    {
                                        case 0:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn0_tublock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn1_tublock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 2:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn2_tublock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 3:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn3_tublock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    switch (P2turn)
                                    {
                                        case 0:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn0_RZblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn1_RZblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 4:
                                {
                                    switch (P2turn)
                                    {
                                        case 0:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn0_LZblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn1_LZblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 5:
                                {
                                    switch (P2turn)
                                    {
                                        case 0:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn0_LLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn1_LLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 2:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn2_LLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 3:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn3_LLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;
                                }
                            case 6:
                                {
                                    switch (P2turn)
                                    {
                                        case 0:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn0_RLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 1:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn1_RLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 2:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn2_RLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                        case 3:
                                            tempx1 = x5; tempx2 = x6; tempx3 = x7; tempx4 = x8;
                                            tempy1 = y5; tempy2 = y6; tempy3 = y7; tempy4 = y8;
                                            turn3_RLblock_init(ref x5, ref x6, ref y5, ref y6, ref x7, ref x8, ref y7, ref y8, ref P2turn);
                                            meet = meetnow(x5, x6, x7, x8, y5, y6, y7, y8, P2youtu);//判断旋转完是否发生左右碰撞
                                            if (meet) //碰撞到左右边框，不用继续判断，直接不能旋转，变回来
                                            {
                                                x5 = tempx1; x6 = tempx2; x7 = tempx3; x8 = tempx4;
                                                y5 = tempy1; y6 = tempy2; y7 = tempy3; y8 = tempy4;
                                            }
                                            P2g.DrawRectangle(P2pen, x5, y5, size, size);
                                            P2g.DrawRectangle(P2pen, x6, y6, size, size);
                                            P2g.DrawRectangle(P2pen, x7, y7, size, size);
                                            P2g.DrawRectangle(P2pen, x8, y8, size, size);
                                            P2g.FillRectangle(P2brush, x5 + 2, y5 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x6 + 2, y6 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x7 + 2, y7 + 2, size - 3, size - 3);
                                            P2g.FillRectangle(P2brush, x8 + 2, y8 + 2, size - 3, size - 3);
                                            break;
                                    }
                                    break;

                                }
                        }

                        //判断添加下落预判图  
                        predict = false;
                        predictcount = 0;
                        predictx1 = x5; predictx2 = x6; predictx3 = x7; predictx4 = x8; predicty1 = y5; predicty2 = y6; predicty3 = y7; predicty4 = y8;
                        while (!predict)
                        {
                            predictcount++;
                            if (predicty1 / size > 19 || predicty2 / size > 19 || predicty3 / size > 19 || predicty4 / size > 19) //下落到最低，直接绘图，不用计算碰撞
                            {
                                if (predictcount != 1)
                                {
                                    P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                    P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                                }
                                predict = true;
                            }
                            else //进行碰撞计算再绘图
                            {
                                if (predict == false)//依次检测有没有发生碰撞 有一个方块发生碰撞，则其余不用检测，不能下落
                                {
                                    if (P2youtu[predicty1 / size + 1, predictx1 / size] == 0)//大坐标转换为数组对应值
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                if (predict == false)
                                {
                                    if (P2youtu[predicty2 / size + 1, predictx2 / size] == 0)
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                if (predict == false)
                                {
                                    if (P2youtu[predicty3 / size + 1, predictx3 / size] == 0)
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                if (predict == false)
                                {
                                    if (P2youtu[predicty4 / size + 1, predictx4 / size] == 0)
                                        predict = false;
                                    else
                                        predict = true;
                                }
                                //下落碰撞检测完毕
                                if (predict == false)//没有发生碰撞，下落
                                {
                                    predicty1 = predicty1 + size;
                                    predicty2 = predicty2 + size;
                                    predicty3 = predicty3 + size;
                                    predicty4 = predicty4 + size;
                                }
                                else
                                {
                                    if (predictcount != 1)
                                    {
                                        P2g.DrawRectangle(P2greypen, predictx1, predicty1, size, size);
                                        P2g.DrawRectangle(P2greypen, predictx2, predicty2, size, size);
                                        P2g.DrawRectangle(P2greypen, predictx3, predicty3, size, size);
                                        P2g.DrawRectangle(P2greypen, predictx4, predicty4, size, size);
                                    }
                                    predict = true;
                                }
                            }
                        }
                        pictureBox2.Image = P2image; //前景
                        pictureBox2.BackgroundImage = P2canvas; // 设置为背景层，就是在内存中建立了一张对应的画布，重新refresh就是再次的加载这个画布


                        break;
                        //return false;//如果要调用KeyDown,这里一定要返回false才行,否则只响应重写方法里的按键.

                        //这里调用一下父类方向,相当于调用普通的KeyDown事件.//所以按空格会弹出两个对话框


                    }
                }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
